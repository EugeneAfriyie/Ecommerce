






export const categories =[

    {
        id:"BP",
        categoryName:"Best President",
       
        nomineeArray: [
            {
                type:"Best President",
                voteNumber:300,
                voteAmount: 56780,
                id:'BP-1',
                image:'image/pic-1.JPG',
                name:'Eugene Afriyie'
            },
            {
                type:"Best President",
                voteNumber:200,
                voteAmount: 140,
                id:'BP-1',
                 image:'image/pic-2.PNG',
                name:'Kwame Eugene'

            },
            {
                type:"Best President",
                voteNumber:290,
                voteAmount: 4990,
                id:'BP-1',
                image:'image/pic-3.PNG',
                name:'Godwin Nkansah'

            },
            {
                type:"Best-President",
                voteNumber:200,
                voteAmount: 110,
                id:'BP-1',
                 image:'image/pic-4.PNG',
                 name:'Francisca Serwaa'
            },
            {
                type:"Best-President",
                voteNumber:500,
                voteAmount: 1810,
                id:'BP-1',
                 image:'image/pic-2.PNG',
                 name:'Rebbeca Serwaa'
            }
            
            
            
            ]
    },
    {
        id:'P',
        categoryName:"President",
        
        nomineeArray:[
            {
                type:"President",
                voteNumber:300,
                voteAmount: 40,
                id:'P-1',
                 image:'image/admin.JPG',
                 name:'Kwame Afriyie'
            },
            {
                type:"president",
                voteNumber:240,
                voteAmount: 40,
                id:'P-2',
                 image:'image/pic-4.PNG',
                 name:'Osei Bonsu'
            },
            {
                type:"president",
                voteNumber:100,
                voteAmount: 40,
                id:['P-3'],
                 image:'image/pic-1.JPG',
                 name:'Rebecca Bonsu'
            },
            {
                type:"president",
                voteNumber:205,
                voteAmount: 60,
                id:'P-4',
                 image:'image/admin.JPG',
                 name:'Yaw Fosu'
            }
            
            
            
            ]
            
        
    },
    {
        id:"F",
        categoryName:"Fashoinable",
        
        nomineeArray:[
    {
        type:"Fashoinable",
        voteNumber:20,
        voteAmount: 10,
        id:'F-1',
         image:'image/pic-1.JPG',
         name:'Sky Gee'
    },
    {
        type:"Fashoinable",
        voteNumber:400,
        voteAmount: 1000,
        id:'F-2',
         image:'image/pic-3.PNG',
         name:'Stoic'
    },
    {
        type:"Fashoinable",
        voteNumber:100,
        voteAmount: 40,
        id:'F-3',
         image:'image/pic-2.PNG',
         name:'Fresh Bowy'
    },
    {
        type:"Fashoinable",
        voteNumber:300,
        voteAmount: 20,
        id:'F-4',
         image:'image/pic-4.PNG',
         name:'Hard Bowy'
    }
    
    
    
    ]
    },
    {
        id:"KOK",
        categoryName:"King Of Kicks",
       
        nomineeArray: [
            {
                type:"King Of Kicks",
                voteNumber:345,
                voteAmount: 110,
                id:"KOK-1",
                 image:'image/admin.JPG',
                 name:'Fresh Bowy'
            },
            {
                type:"King Of Kicks",
                voteNumber:600,
                voteAmount: 660,
                id:'KOK-2',
                 image:'image/pic-1.JPG',
                 name:'Money Bowy'
            },
            {
                type:"King Of Kicks",
                voteNumber:660,
                voteAmount: 770,
                id:'KOK-3',
                 image:'image/pic-4.PNG',
                 name:'Ability bowy'
            },
            {
                type:"King Of Kicks",
                voteNumber:2550,
                voteAmount: 45260,
                id:'KOK-4',
                 image:'image/pic-2.PNG',
                 name:'Silent Bowy'
            },
            {
                type:"King Of Kicks",
                voteNumber:2550,
                voteAmount: 45260,
                id:'KOK-4',
                 image:'image/pic-2.PNG',
                 name:'Some Nigga'
            }
            
            
            
            ]
    }


]
