
 import {menuFunc,renderFAQ } from "./pageFun.js";

 renderFAQ();
 menuFunc();
